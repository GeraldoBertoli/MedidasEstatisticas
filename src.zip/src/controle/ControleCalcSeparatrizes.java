package controle;

public class ControleCalcSeparatrizes {

}
